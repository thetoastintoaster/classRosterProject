#pragma once
#include <string>
using namespace std;

enum DegreeProgram {
    SECURITY, NETWORK, SOFTWARE
};

static const string degreeProgramString[] = {"SECURITY", "NETWORK", "SOFTWARE"};